Page({
  data: {
    part1: "在此详细介绍各种疾病表现的具体症状",
    part2: "添加症状标签tag来快速定位可能的病状",
    part3: "对接人工医师一对一服务获得专业医嘱",
    part4: "每日向您推送几条健康的饮食作息建议",
    part5: "正在努力补充添加有趣的新功能中。。。",
    icon1: "https://www.freeimg.cn/i/2024/01/11/659ff33b3e888.png",
    icon2: "https://www.freeimg.cn/i/2024/01/11/659ff1bac5442.png",
    icon3: "https://www.freeimg.cn/i/2024/01/11/659fef9073fc3.png",
    icon4: "https://www.freeimg.cn/i/2024/01/11/659ff299a8dfa.png",
    icon5: "https://www.freeimg.cn/i/2024/01/11/659ff0e4c33ba.png",
  },
  onShow: function () {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        // 首页为 0
        selected: 0
      })
    }
  },
  f1: function (event) {
    wx.navigateTo({
      url: "/grammar/grammar"
    })
  },
  f2: function (event) {
    wx.navigateTo({
      url: "/speh/speh"
    })
  },
  f3: function (event) {
    wx.navigateTo({
      url: "/viep/viep"
    })
  },
  f4: function (event) {
    wx.navigateTo({
      url: "/news/news"
    })
  }
}, )