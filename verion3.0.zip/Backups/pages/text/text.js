
Page({
bindchooseavatar(e) {
  console.log("avatarUrl",e.detail.avatarUrl)
},
})