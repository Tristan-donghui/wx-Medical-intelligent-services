let page = 0
var app = getApp();
Page({
  data: {
    article: []
  },
  onLoad() {
    page = 0
    wx.cloud.database().collection('views').limit(5)
      .get()
      .then(res => {
        this.setData({
          article: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  onReachBottom() {
    page++
    wx.cloud.database().collection('views').limit(5)
      .skip(page * 5)
      .get()
      .then(res => {
        this.setData({
          article: this.data.article.concat(res.data)
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  f1: function (event) {
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_4 = event.currentTarget.dataset.id_4
    var id_5 = event.currentTarget.dataset.id_5
    var id_6 = event.currentTarget.dataset.id_6
    var id_7 = event.currentTarget.dataset.id_7
    var id_8 = event.currentTarget.dataset.id_8
    var id_9 = event.currentTarget.dataset.id_9

    wx.cloud.database().collection('historylis') //判断是否在历史记录里面
      .where({
        Nickname: app.globalData.user.Nickname,
        id: id_1
      })
      .get()
      .then(res => {
        if (res.data != 0) {
          wx.cloud.database().collection('historylis') //更新历史记录
            .where({
              Nickname: app.globalData.user.Nickname,
              id: id_1
            })
            .update({
              data: {
                timeStamp: parseInt(Date.parse(new Date())), //时间戳
              }
            })
        } else {
          //只要有点击且历史记录里面没有就添加进历史记录
          wx.cloud.database().collection('historylis')
            .add({
              data: {
                Nickname: app.globalData.user.Nickname,
                id: id_1,
                location: id_2,
                imagepath: id_4,
                name: id_5,
                idname: id_6,
                music: id_7,
                flag: id_8,
                judge: id_9,
                timeStamp: parseInt(Date.parse(new Date())), //时间戳
              }
            })
        }
      })
    wx.navigateTo({
      url: "/listen_part/listen_part?id_1=" + id_1 + "&id_2=" + id_2 + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6 + "&id_7=" + id_7 + "&id_8=" + id_8 + "&id_9=" + id_9,
    })
  }
})