let shoucang = false;
var app = getApp();
Page({
  data: {
    circular: true,
    color1: '#1691f5',
    imgUrl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
    currentData: 0,
    curring: -1,
    image2: '',
    image3: '',
    mid1: '',
    wordlist: [{
        word: '',
      },
      {
        word: '',
      },
      {
        word: '',
      },
      {
        word: '',
      },
      {
        word: '',
      },
      {
        word: '',
      },
      {
        word: '',
      },
    ],
    detail: [{
        id: '1',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '2',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '3',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '4',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
    ],
    number: 0,
    answer: 0,
  },
  onLoad: function (options) {
    this.setData({
      mid: options.id,
      imageurl: "",
    })
    wx.cloud.database().collection('shoucang') //判断是否在收藏里面
      .where({
        Nickname: app.globalData.user.Nickname,
        id: this.data.mid
      })
      .get()
      .then(res => {
        if (res.data != 0) {
          shoucang = true
          this.setData({
            imageurl: "https://7461-tan-ran-mian-dui-6f6bupycd7c158e-1314199310.tcb.qcloud.la/image/shoucangyes%20.png"
          })
        } else {
          console.log("shoucang请求失败", res)
          shoucang = false
          this.setData({
            imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png"
          })
        }
      })
      .catch(err => {
        console.log("请求失败", err)
      })
    wx.cloud.database().collection('article')
      .doc(this.data.mid)
      .get()
      .then(res => {
        this.setData({
          mid1: res.data.level,
          mid2: res.data.ming,
          mid3: res.data.skill,
          mid4: res.data.imagepath,
          mid5: res.data.name,
          mid6: res.data.location,
          mid7: res.data.analysis,
          image2: res.data.level2,
          image3: res.data.level3,
          ['detail[0].title']: res.data.question1,
          ['detail[1].title']: res.data.question2,
          ['detail[2].title']: res.data.question3,
          ['detail[3].title']: res.data.question4,
          ['detail[0].answer']: res.data.answer1,
          ['detail[1].answer']: res.data.answer2,
          ['detail[2].answer']: res.data.answer3,
          ['detail[3].answer']: res.data.answer4,
          ['detail[0].array[0].name']: res.data.option1_1,
          ['detail[0].array[1].name']: res.data.option1_2,
          ['detail[0].array[2].name']: res.data.option1_3,
          ['detail[0].array[3].name']: res.data.option1_4,
          ['detail[1].array[0].name']: res.data.option2_1,
          ['detail[1].array[1].name']: res.data.option2_2,
          ['detail[1].array[2].name']: res.data.option2_3,
          ['detail[1].array[3].name']: res.data.option2_4,
          ['detail[2].array[0].name']: res.data.option3_1,
          ['detail[2].array[1].name']: res.data.option3_2,
          ['detail[2].array[2].name']: res.data.option3_3,
          ['detail[2].array[3].name']: res.data.option3_4,
          ['detail[3].array[0].name']: res.data.option4_1,
          ['detail[3].array[1].name']: res.data.option4_2,
          ['detail[3].array[2].name']: res.data.option4_3,
          ['detail[3].array[3].name']: res.data.option4_4,
          ['wordlist[0].word']: res.data.word1,
          ['wordlist[1].word']: res.data.word2,
          ['wordlist[2].word']: res.data.word3,
          ['wordlist[3].word']: res.data.word4,
          ['wordlist[4].word']: res.data.word5,
          ['wordlist[5].word']: res.data.word6,
          ['wordlist[6].word']: res.data.word7,
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  clickImg1: function (e) {
    var imgUrl = this.data.mid1;
    wx.previewImage({
      urls: [imgUrl], //需要预览的图片http链接列表，注意是数组
      current: '', // 当前显示图片的http链接，默认是第一个
      success: function (res) {},
      fail: function (res) {},
      complete: function (res) {},
    })
  },
  clickImg2: function (e) {
    var imgUrl = this.data.image2;
    wx.previewImage({
      urls: [imgUrl], //需要预览的图片http链接列表，注意是数组
      current: '', // 当前显示图片的http链接，默认是第一个
      success: function (res) {},
      fail: function (res) {},
      complete: function (res) {},
    })
  },
  clickImg3: function (e) {
    var imgUrl = this.data.image3;
    wx.previewImage({
      urls: [imgUrl], //需要预览的图片http链接列表，注意是数组
      current: '', // 当前显示图片的http链接，默认是第一个
      success: function (res) {},
      fail: function (res) {},
      complete: function (res) {},
    })
  },
  checkCurrent1: function (e) {
    this.setData({
      color1: '#1691f5'
    });
    circular: true;
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  checkCurrent2: function (e) {
    this.setData({
      color1: '#FF8247'
    });
    circular: true;
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  checkCurrent3: function (e) {
    this.setData({
      color1: 'rgb(149, 0, 248)'
    });
    circular: true;
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  // // 加入书架
  // chooseAddBookrack: function() {
  //     let value = this.data.addBookrackSucceed;
  //     wx.showToast({
  //       title: '已收藏',      //标题
  //       icon: "success",        //图标类型, 默认success
  //       duration: 1500                //提示框停留时间, 默认1500ms
  //     })
  //     this.setData({
  //       addBookrackSucceed: !value
  //     })
  //     console.log(value)
  // },
  // cancelAddBookrack: function() {
  //   let value = this.data.addBookrackSucceed;
  //   wx.showToast({
  //     title: '已取消',      //标题
  //     icon: "success",        //图标类型, 默认success
  //     duration: 1500                //提示框停留时间, 默认1500ms
  //   })
  //   this.setData({
  //     addBookrackSucceed: !value
  //   })
  //   console.log(value)
  // },


  //改变收藏状态
  clickme() {
    if (shoucang == false) {
      this.setData({
        imageurl: "https://i.imgtg.com/2023/06/07/O5eJAb.png"
      })
      wx.cloud.database().collection('shoucang')
        .add({
          data: {
            Nickname: app.globalData.user.Nickname,
            id: this.data.mid,
            level: this.data.mid1,
            ming: this.data.mid2,
            skill: this.data.mid3,
            imagepath: this.data.mid4,
            name: this.data.mid5,
            location: this.data.mid6,
            analysis: this.data.mid7,
          }
        })
      wx.showToast({
        title: '已收藏', //标题
        icon: "success", //图标类型, 默认success
        duration: 1500 //提示框停留时间, 默认1500ms
      })
    } else {
      this.setData({
        imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
      })
      wx.cloud.database().collection('shoucang')
        .where({
          id: this.data.mid
        })
        .remove()
      wx.showToast({
        title: '已取消', //标题
        icon: "success", //图标类型, 默认success
        duration: 1500 //提示框停留时间, 默认1500ms
      })
    }
    shoucang = !shoucang
  },
  //获取当前滑块的index
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
  },
  //点击切换，滑块index赋值

  onShareAppMessage: function () {
    return {
      title: this.data.mid2 + "个人信息"
    }
  },
  tel: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.mid5,
    })
  },
  previous: function (e) {
    this.setData({
      number: this.data.number - 1,
      curring: this.data.curring - 1,
    })
  },
  radioChange: function (e) {
    let index = e.currentTarget.dataset.index
    let id = e.currentTarget.dataset.id
    let detail = this.data.detail
    for (let i = 0; i < detail.length; i++) {
      if (detail[i].id == id) {
        detail[i].array[index].usname = true
        for (let j = 0; j < detail[i].array.length; j++) {
          if (j != index) {
            detail[i].array[j].usname = false
          }
        }
      }
    }
    this.setData({
      detail: detail
    })
  },
  nextstep: function (e) {
    let detail = this.data.detail
    let number = this.data.number
    let curring = this.data.curring
    let usname = 0;
    for (let i = 0; i < detail[number].array.length; i++) {
      if (!detail[number].array[i].usname) {
        usname++
      }
    }
    if (usname == detail[number].array.length) {
      wx.showToast({
        title: '答题选项不能为空',
        icon: 'none',
        duration: 2000
      })
      return false;
    }
    curring++
    number++
    this.setData({
      curring: curring,
      number: number,
    })
  },
  subsic: function (e) {
    let detail = this.data.detail
    let curring = this.data.curring
    let answer = 0
    let letter = ''
    let number = this.data.number
    for (let i = 0; i < detail.length; i++) {
      for (let j = 0; j < detail[i].array.length; j++) {
        if (detail[i].array[j].usname) {
          letter = detail[i].answer - 1
          if (letter == j) {
            answer++
          }
        }
      }
    }
    wx.showToast({
      title: '答对了:' + answer + '题',
      icon: 'none',
      duration: 2000
    })
    curring++
    number++;
    if (curring > 4) {
      curring = -1
    }
    this.setData({
      curring: curring,
      number: number,
    })
  },
  notebook(event) {
    wx.showModal({
      title: "是否加入notebook",
      success(res) {
        if (res.confirm == true) {
          wx.cloud.database().collection('notebook')
            .where({
              Nickname: app.globalData.user.Nickname,
              word: event.currentTarget.dataset.word,
            })
            .get()
            .then(reg => {
              if (reg.data != 0) {
                wx.showToast({
                  title: '已收藏', //标题
                  icon: "success", //图标类型, 默认success
                  duration: 1500 //提示框停留时间, 默认1500ms
                })
              } else {
                wx.cloud.database().collection('notebook')
                  .add({
                    data: {
                      Nickname: app.globalData.user.Nickname,
                      word: event.currentTarget.dataset.word
                    }
                  })

              }
            })
        }
      }
    })
  },
})